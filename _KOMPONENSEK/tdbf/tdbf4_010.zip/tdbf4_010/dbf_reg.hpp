// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'dbf_reg.pas' rev: 4.00

#ifndef dbf_regHPP
#define dbf_regHPP

#pragma delphiheader begin
#pragma option push -w-
#include <UDbfCommon.hpp>	// Pascal unit
#include <UDbfFieldDef.hpp>	// Pascal unit
#include <UDbfEngine.hpp>	// Pascal unit
#include <UDbfCursor.hpp>	// Pascal unit
#include <UDbfMemo.hpp>	// Pascal unit
#include <UDbfIndex.hpp>	// Pascal unit
#include <UDbfFile.hpp>	// Pascal unit
#include <UDbfPagedFile.hpp>	// Pascal unit
#include <dbf.hpp>	// Pascal unit
#include <Exptintf.hpp>	// Pascal unit
#include <DsgnIntf.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dbf_reg
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Dbf_reg */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Dbf_reg;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// dbf_reg
