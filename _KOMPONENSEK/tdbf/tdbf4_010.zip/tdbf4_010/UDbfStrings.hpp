// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'UDbfStrings.pas' rev: 4.00

#ifndef UDbfStringsHPP
#define UDbfStringsHPP

#pragma delphiheader begin
#pragma option push -w-
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Udbfstrings
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE AnsiString STRING_FILE_NOT_FOUND;
extern PACKAGE AnsiString STRING_VERSION;
extern PACKAGE AnsiString STRING_ABOUT;
extern PACKAGE AnsiString STRING_FILTER;
extern PACKAGE AnsiString STRING_FIELD_TOO_LONG;
extern PACKAGE AnsiString STRING_INDEX_BASED_ON_UNKNOWN_FIELD;
extern PACKAGE AnsiString STRING_CANNOT_OPEN_INDEX;

}	/* namespace Udbfstrings */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Udbfstrings;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UDbfStrings
